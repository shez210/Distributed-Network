import javax.crypto.SealedObject;
import auctioneer.Auction;
import auctioneer.Item;
import auctioneer.User;
import helper.CrytpoHelper;
import java.io.*;
import java.security.*;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.DSAPublicKey;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class AuctionClient {
    // directory with pubs & private keys
    // server must have server priv key, clients shouldn't have server private!!!!
    private static final String AUCTION_HOME = System.getProperty("user.home")+"/auction";//Shared Saved location for keys

    public static final AuctionClient client = new AuctionClient();
    private static Auction a;
    private User currentUser;
    private static Scanner cin = new Scanner(System.in);

    public static void main(String args[])
    {
        /**
         * Creates the files for the public and private ekys
         */
        try
        {
            File dir = new File(AUCTION_HOME);//if file doesnt ecist, make one
            if (!dir.exists()) {
                dir.mkdir();

            }
            dir = new File(AUCTION_HOME+"/keys");
            if (!dir.exists()) {
                dir.mkdir();

            }
            dir = new File(AUCTION_HOME+"/keys/private");
            if (!dir.exists()) {
                dir.mkdir();

            }
            dir = new File(AUCTION_HOME+"/keys/public");
            if (!dir.exists()) {
                dir.mkdir();
            }
            a = RMIRequestHandler.reconnect();
        } catch (Exception e) {
            System.out.println("\nFailed to find RMI");
            e.printStackTrace();
            return;
        }

        /**
         * This is the first window client sees. Has 3 options
         * Sign up, Login or Exit
         */
        int choice = client.loginMenu();
        boolean loggedIn = false;

        while (choice != 3)
        {
            if (choice == 1)
            {
                if (client.loginUser()) //goes to login
                {
                    loggedIn = true;
                }
            }
            else if (choice == 2)
            {
                if (client.createUser()) //goes to create user
                {
                    loggedIn = false;
                }
            }

            while (loggedIn) //while true
            {
                choice = client.userMenu();

                if (choice == 1)
                {
                    client.createAuction();
                }
                else if (choice == 2)
                {
                    client.printActiveAuctions();
                    client.bidAuction();
                }
                else if (choice == 3)
                {
                    client.printActiveAuctions();
                    client.closeAuction();
                }
                else if (choice == 4)
                {
                    client.printActiveAuctions();
                }
                else if (choice == 5)
                {
                    client.currentUser = null;
                    loggedIn = false;
                }
            }

            choice = client.loginMenu();
        }
    }

    /**
     * Method for the login menu
     * @return the choice made by user
     */
    private int loginMenu() {
        int choice = 0;

        do {
            System.out.println("\nWelcome!\n"
                    + "Please choose one of the following:\n"
                    + "1. Login\n"
                    + "2. Signup\n"
                    + "3. Exit");

            do
            {
                System.out.print("\nEnter Your Choice: ");
                choice = getNextInt();//makes sure choice is an int ****CORNER CASE*****
            }while(choice == -1);

        } while (choice < 1 || choice > 3);

        return choice;
    }

    /**
     * Method for the user to log in
     * @return true if logged, false if not
     */
    private boolean loginUser() {
        String name, email;

        System.out.print("\nLOGIN\n\nEnter username: ");
        name = cin.next();

        System.out.print("Enter email: ");
        email = cin.next();

        // loading keypair for the user.
        KeyPair kp = getKeysForUser(name);
        User user = new User(name, email, kp.getPublic());//user has a public key connected to THAT user
        try {
            // ONE read the server public key -> this will be used to verify the challenge
            PublicKey serverPubKey = loadServerKey();
            Signature dsa = Signature.getInstance("DSA");
            // Challenge Sever
            // TWO ->  generate random number
            Integer theNumber = new Random().nextInt();//can be any number/object

            // THREE -> request the server to sign it
            SealedObject sealedObject = new SealedObject(theNumber, CrytpoHelper.encryptCipher());//encrypt the number
            SealedObject signedNumber = RMIRequestHandler.sign(a, sealedObject);//client requests the FE to sign it

            //   verifying signature and value
            // FOUR -> verify the server signature and check the number
            if (!((SignedObject)signedNumber.getObject(CrytpoHelper.decryptCipher())).verify(serverPubKey, dsa) ||
                    !theNumber.equals(((SignedObject) signedNumber.getObject(CrytpoHelper.decryptCipher())).getObject())) {//if not signed object or the number false
                System.out.println("ERROR!!");
                return false;
            }
            System.out.println("--> Server has been verified!");
            // Server challenges client. Already assumed to have each others Key #1,
            // ask number to the server
            // TWO -> request the server a challenge for this user
            theNumber = (Integer) (RMIRequestHandler.challenge(a,user.getUserName()).getObject(CrytpoHelper.decryptCipher()));

            // FOUR -> signit and send it back
            RMIRequestHandler.challengeAnswer(a, user.getUserName(), new SealedObject(signWithKey(theNumber, kp.getPrivate()), CrytpoHelper.encryptCipher()));

            System.out.println("--> Server challenged passed!!, Client now verified");

            if (RMIRequestHandler.login(a, user)) {

                currentUser = user;//if user matches, login else dont
                return true;
            } else {
                System.out.println("\nAccount with the provided username and email doesn't exist.");
            }
        } catch (Exception e) {
            System.out.println("\nFailed to login\nError Details:\n" + e.getMessage() + "\n");
        }


        return false;
    }

    /**
     * Getting all the keys for the user. Key is based on the username
     * @param name
     * @return
     */
    private KeyPair getKeysForUser(String name) {
        String filename = name + ".key";
        String privateKeyLocation = AUCTION_HOME + "/keys/private/" + filename;
        String publicKeyLocation = AUCTION_HOME + "/keys/public/" + filename;

        // Check the file exists
        if (!new File(privateKeyLocation).exists()) {
            throw new RuntimeException("Can't find key");
        }

        if (!new File(publicKeyLocation).exists()) {
            throw new RuntimeException("Can't find key");
        }

        try {
            // Read in private key for the user
            FileInputStream fs = new FileInputStream(new File(privateKeyLocation));
            ObjectInputStream ds = new ObjectInputStream(fs);
            byte[] prKey = (byte[]) ds.readObject();
            fs.close();
            ds.close();
            KeyFactory keyFactory = KeyFactory.getInstance("DSA");
            KeySpec ks = new PKCS8EncodedKeySpec(prKey);
            PrivateKey privateKey = (DSAPrivateKey) keyFactory.generatePrivate(ks);

            // Load in public key for the user
            fs = new FileInputStream(new File(publicKeyLocation));
            ds = new ObjectInputStream(fs);
            byte[] puKey = (byte[]) ds.readObject();
            fs.close();
            ds.close();
            ks = new X509EncodedKeySpec(puKey);
            PublicKey publicKey = (DSAPublicKey) keyFactory.generatePublic(ks);

            return new KeyPair(publicKey, privateKey);//This will be the pair used for the USER

        } catch (Exception e) {
            throw new RuntimeException("Can't user load keys");
        }
    }

    public PublicKey loadServerKey() {
        try {
            // Load in server public key. Don't need the private key
            FileInputStream fs = new FileInputStream(new File(AUCTION_HOME + "/keys/public/server.key"));
            ObjectInputStream ds = new ObjectInputStream(fs);
            byte[] puKey = (byte[]) ds.readObject();
            fs.close();
            ds.close();
            KeySpec ks = new X509EncodedKeySpec(puKey);
            KeyFactory keyFactory = KeyFactory.getInstance("DSA");

            return keyFactory.generatePublic(ks);
        } catch (Exception ex) {
            throw new RuntimeException("Can't open server public key");
        }
    }
    public KeyPair generateKeys(String user) {
        try {
            String pubKeyLocation = AUCTION_HOME + "/keys/public/" + user + ".key";
            String privKeyLocation = AUCTION_HOME + "/keys/private/" + user + ".key";
            // checks wether the public and private key already exists, if they do, it loads them from the filesystem
            if (new File(privKeyLocation).exists() && new File(pubKeyLocation).exists()) {
                return getKeysForUser(user);//if dirs exist, then generate keys
            }

            KeyPairGenerator generator = KeyPairGenerator.getInstance("DSA");
            generator.initialize(1024, new SecureRandom());
            KeyPair keys = generator.generateKeyPair();


            PublicKey publicKey = keys.getPublic();
            PrivateKey privateKey = keys.getPrivate();

            ObjectOutputStream fos = new ObjectOutputStream(new FileOutputStream(AUCTION_HOME + "/keys/public/" + user + ".key"));
            fos.writeObject(publicKey.getEncoded());
            fos.close();

            System.out.println("Public key written.");

            fos = new ObjectOutputStream(new FileOutputStream(AUCTION_HOME + "/keys/private/" + user + ".key"));
            fos.writeObject(privateKey.getEncoded());
            fos.close();

            System.out.println("Private key written.");
            return keys;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method for a user to be created and stored on Array List
     * @return
     */
    private boolean createUser() {
        String name, email = "";

        System.out.print("\nCREATE ACCOUNT\nEnter username: ");
        name = cin.next();

        System.out.print("Enter email: ");
        email = cin.next();

        while(!email.contains("@"))//***CORNER CASE*** If Email has to contain @
        {
            System.out.print("Email must contain @\n\nEnter email: ");
            email = cin.next();
        }

        // generate keypair for user on account creation!!!
        KeyPair kp = generateKeys(name);

        User user = new User(name, email, kp.getPublic());
        try
        {

            if (RMIRequestHandler.addUser(a, user))//if user is added, then add else dont
            {
                System.out.println("\nAccount created!");
                //currentUser = user;
                return true;
            }
            else
            {
                System.out.println("\nEmail already in use!");//****CORNER CASE*****//user cant reg with same email
            }
        }
        catch (Exception e)
        {
            System.out.println("\nFailed to create user (serious)\nError Details:\n" + e.getMessage() + "\n");
        }
        return false;
    }

    /**
     * Method for the User ControlPanel
     * @return the choice of the user
     */
    private int userMenu() {
        int choice = 0;

        do {
            System.out.println("\nWelcome " + currentUser.getUserName() + "!\n"
                    + "Please choose one of the following:\n"
                    + "1. Create Auction\n"
                    + "2. Bid\n"
                    + "3. Close Auction\n"
                    + "4. View Auctions\n"
                    + "5. Logout");


            do
            {
                System.out.print("\nEnter Your Choice: ");
                choice = getNextInt();//***CORNER CASE***//checks if its an int
            }while(choice == -1);//***CORNER CASE***//checks if its not a negative number

        } while (choice < 1 || choice > 5);

        return choice;
    }

    /**
     * Method for Creation of an Auction
     */
    private void createAuction() {
        double startPrice, reservePrice;
        String name, description;


        System.out.println("\nCREATE AUCTION");
        cin.nextLine();

        System.out.print("Enter item name: ");
        name = cin.nextLine();

        System.out.print("Enter description:  ");
        description = cin.nextLine();

        do
        {
            System.out.print("Enter Reserve price: £");
            reservePrice = getNextDouble();//***CORNER CASE***//checks if its a double
        }while(reservePrice == -1);//***CORNER CASE***//checks if its not a negative number

        do
        {
            System.out.print("Enter Start price: £");
            startPrice = getNextDouble();//***CORNER CASE***//checks if its  a double number
        }while(startPrice == -1);//***CORNER CASE***//checks if its not a negative number



        if (startPrice > reservePrice) {//if the start if more than reserve **CORNER CASE***
            System.out.println("Prices Do Not Match");
            return;
        }


        Item item = new Item(currentUser, name, description, startPrice, reservePrice);
        try {
            if (RMIRequestHandler.addItem(a, item)) {//if items has been successfully added then
                System.out.println("\nAuction created with ID = " +item.getID() + "  " + item.getName() + "  "
                        + item.getDescription() + "  £" + item.getCurrentPrice());
            } else {
                System.out.println("\nFailed to create auction");
            }
        } catch (Exception e) {
            System.out.println("Failed to create auction \nError Details:\n" + e.getMessage() + "\n");
            e.printStackTrace();
        }
    }

    /**
     * Printing the Active Auctions
     */
    private void printActiveAuctions() {
        ArrayList<Item> list;//storing items in an array list
        Item current;
        String price;

        try {
            list = RMIRequestHandler.getAvailableAuctions(a);

            System.out.println("\n----------------------------");
            System.out.println("This is the ACTIVE AUCTIONS");
            System.out.println("------------------------------");

            System.out.println("\nID\t\tName\t\tHighest Bid");

            for (int i = 0, s = list.size(); i < s; i++) {
                current = list.get(i);
                price = String.valueOf(current.getCurrentPrice());

                /**if price is below 3 numbers then add 0
                 */
                if(price.contains("."))
                {
                    String temp = price.substring(price.indexOf('.'));
                    while(temp.length() < 3)
                    {
                        temp = temp + "0";
                        price = price + "0";
                    }
                }
                else
                {
                    price = price + ".00";
                }
                System.out.println("\n" + current.getID() + "\t" + current.getName() + "\t\t" + "£"+price);
            }
        } catch (Exception e) {
            System.out.println("\nError occurred while displaying active auctions!\n" + e.getMessage() + "\n");
        }
    }

    /**
     * Method for Bidding of an item
     */
    private void bidAuction() {
        int id;
        boolean result;
        double amount;

        System.out.println("\nBID");
        do
        {
            System.out.print("\nEnter ID of auction: ");
            id = getNextInt();//**CORNER CASE**//makes sure that its an int
        }while(id == -1);//**CORNER CASE**//makes sure its a positive number

        do
        {
            System.out.print("Enter amount: ");
            amount = getNextDouble();//**CORNER CASE**//makes sure that its an double
        }while(amount == -1);//**CORNER CASE**//makes sure its a positive number

        try {
            result = RMIRequestHandler.bid(a, id, amount, currentUser);//result of bid
        } catch (Exception e) {
            System.out.print("\nError occured while trying to bid!\n" + e.getMessage() + "\n");
            return;
        }

        if (result == true) {
            System.out.println("\nBid successful.");//if nothing goes wrong its done else not
        } else {
            System.out.println("\nBid successful.");
        }
    }

    /**
     * Method for closing an auction
     */
    private void closeAuction() {
        int id;
        String response;

        System.out.println("\nCLOSE AUCTION");
        do
        {
            System.out.print("\nEnter ID of auction: ");
            id = getNextInt();//**CORNER CASE**//makes sure that its an int
        }while(id == -1);//**CORNER CASE**//makes sure its a positive number

        try {
            response = RMIRequestHandler.closeAuction(a, id, currentUser);
            switch (response.charAt(0)) {
                case '0':
                    System.out.println("\nItem is not your own/doesn't exist");
                    break;
                case '1':
                    System.out.println("\nItem closed, but didn't meet reserve");
                    break;
                case '2':
                    System.out.println("\nItem closed. Winner is: " + response.substring(2));//grabs the winner details
                    break;
                default:
                    System.out.println("\nError");
                    break;
            }
        } catch (Exception e) {
            System.out.println("\nCouldn't close auction (serious)\nError Details:\n" + e.getMessage() + "\n");
        }
    }

    /**
     * Method to check if input is an int
     * @return
     */
    private int getNextInt()
    {
        try
        {
            int input = cin.nextInt();
            return input;
        }
        catch(Exception e)
        {
            cin.reset();
            cin.nextLine();
            System.out.println("\nInteger input required!\nError Details:\n" + e.getMessage() + "\n");
            return -1;
        }
    }

    /**
     * Method to check if input is a double
     * @return
     */
    private double getNextDouble()
    {
        try
        {
            double input = cin.nextDouble();
            return input;
        }
        catch(Exception e)
        {
            cin.reset();
            cin.nextLine();
            System.out.println("\nDouble input required!\nError Details:\n" + e.getMessage() + "\n");
            return -1;
        }
    }

    private AuctionClient() {

    }

    public static AuctionClient getInstance() {
        return client;
    }

    /**
     * Method to sign the serializable object (sealed object) with a signature via PK
     * @param theObject
     * @param pk
     * @return
     */
    public SignedObject signWithKey(Serializable theObject, PrivateKey pk)  {
        SignedObject obj = null;

        try {

            obj = new SignedObject(theObject, pk, Signature.getInstance("DSA"));

            return obj;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return obj;
    }

}
