import javax.crypto.SealedObject;

import auctioneer.Auction;
import auctioneer.Item;
import auctioneer.User;

import java.net.ConnectException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class RMIRequestHandler {

	/**
	 * A reconnect function to check for a reconnect on THAT service and port
	 * @return To see if it has been connected or not
	 * @throws Exception
	 */
	public static Auction reconnect() throws Exception {
		Auction a = null;
		try {
			String url = "rmi://localhost:" + (Auction.FE_SERVICE_PORT ) + "/" + Auction.FE_SERVICE_NAME ;
			a = (Auction) Naming.lookup(url);
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			a = null;
		}
		if(a == null)
			throw new Exception("Check FE server is running or not ");
		return a;
	}

	/**
	 * Sends request from client to FE for adding the user.
	 * @param a = the auction interface being called
	 * @param user = THAT USER
	 * @return the boolean to see if that user has been added or not. If true = then add else dont add
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static boolean addUserRequest(Auction a, User user) throws ConnectException, RemoteException {
		return a.addUser(user);
	}

	/**
	 * Client request to FE to add the user. If request  = true, then do this method
	 * @param a = The remote interface "auction"
	 * @param user - THAT user
	 * @return the boolean if that user has been added
	 * @throws Exception
	 */
	public static boolean addUser(Auction a, User user) throws Exception {
		try {
			return addUserRequest(a,user);//if true, then add
		} catch (ConnectException | RemoteException e) {//***IF CLIENT DISCONNECTS, try to reconnect
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			return addUserRequest(nextAvailableService, user);//**if reconnected, try again.
		}
	}

	/**
	 * Sends request from client to FE to sign the object (contains challenge and username)
	 * @param a = The remote interface
	 * @param object - The sealed object being passed across network
	 * @return The sealed object being passed
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static SealedObject signRequest(Auction a, SealedObject object) throws ConnectException, RemoteException {
		return a.sign(object);
	}

	/**
	 * If the request has been accepted, then do this method
	 * @param a - The auction interface
	 * @param number - The number held with in the sealed object. This number is the challenge
	 * @return The sealed object
	 * @throws Exception
	 */
	public static SealedObject sign(Auction a, SealedObject number) throws Exception {
		try {
			return signRequest(a, number);//if request == true, then sign
		} catch (ConnectException | RemoteException e) {//**If connection dropped, try to reconnect
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			return signRequest(nextAvailableService, number);//**if reconnected, re do the function
		}
	}

	/**
	 * The request from client who is challenging the server
	 * @param a - The auction interface
	 * @param userName - The username challenging server
	 * @return The sealed object containing the request
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static SealedObject challengeRequest(Auction a, String userName) throws ConnectException, RemoteException {
		return a.challenge(userName);//returns the challenge
	}

	/**
	 * If request has been accepted, then do this method. Method challenges the server
	 * @param a - The remote interface
	 * @param userName  - the username
	 * @return The sealed object containing the challenge
	 * @throws Exception
	 */
	public static SealedObject challenge(Auction a, String userName) throws Exception {
		try {
			return challengeRequest(a, userName);//returns the challenge request.
		} catch (ConnectException | RemoteException e) {//**If disconnected, try reconnecting
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			return challengeRequest(nextAvailableService, userName);
		}
	}

	/**
	 * Method for challenging the answer of the server. (Server verifying client)
	 * @param a - The interface
	 * @param userName - The username of THAT user
	 * @param signedNumber - The signed number
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static void challengeAnswerRequest(Auction a, String userName, SealedObject signedNumber) throws ConnectException, RemoteException {
		a.challengeAnswer(userName, signedNumber);
	}

	public static void challengeAnswer(Auction a, String userName, SealedObject sealedNumber) throws Exception {
		try {
			challengeAnswerRequest(a, userName, sealedNumber);
		} catch (ConnectException | RemoteException e) {
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			challengeAnswerRequest(nextAvailableService, userName, sealedNumber);
		}
	}

	/**
	 * A request from a client to FE to login.
	 * @param a Passes the remote interface
	 * @param user passes the User (username, email)
	 * @return True if request is done, false if not
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static boolean loginRequest(Auction a, User  user) throws ConnectException, RemoteException {
		return a.login(user);
	}

	public static boolean login(Auction a, User  user) throws Exception {
		try {
			return loginRequest(a, user);
		} catch (ConnectException | RemoteException e) {
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			return loginRequest(nextAvailableService, user);
		}
	}

	/**
	 * When Client wants to add an item, requests FE to do this
	 * @param a - The interface
	 * @param item The ITem (name, desc, prices)
	 * @return True if added, false if not added
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static boolean addItemRequest(Auction a, Item  item) throws ConnectException, RemoteException {
		return a.addItem(item);
	}

	public static boolean addItem(Auction a, Item  item) throws Exception {
		try {
			return addItemRequest(a, item);
		} catch (ConnectException | RemoteException e) {
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			return addItemRequest(nextAvailableService, item);
		}
	}

	/**
	 * When a client requests to close the auction.
	 * @param a The auction interface
	 * @param id The ID of THAT item
	 * @param currentUser the current user wanting to close the autction
	 * @return The string to if it closes
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static String closeAuctionRequest(Auction a, Integer id, User currentUser) throws ConnectException, RemoteException {
		return a.closeAuction(id, currentUser);
	}

	public static String closeAuction(Auction a, Integer id, User currentUser) throws Exception {
		try {
			return closeAuctionRequest(a, id, currentUser);
		} catch (ConnectException | RemoteException e) {
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			return closeAuctionRequest(nextAvailableService, id, currentUser);
		}
	}

	/**
	 * When a client wants to request a BID for an item
	 * @param a - THe inteface provided
	 * @param id The id of the Item
	 * @param amount The amount bidded
	 * @param currentUser - The current user bidding
	 * @return True - if bidded, false if not
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static Boolean bidRequest(Auction a, Integer id, double amount, User currentUser) throws ConnectException, RemoteException {
		return a.bid(id, amount, currentUser);
	}

	public static Boolean bid(Auction a, Integer id, double amount, User currentUser) throws Exception {
		try {
			return bidRequest(a, id, amount, currentUser);
		} catch (ConnectException | RemoteException e) {
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			return bidRequest(nextAvailableService, id, amount, currentUser);
		}
	}

	/**
	 * Client wants to request the available auctions to the FE
	 * @param a The interface provided
	 * @return The arraylist of item which contains all items listed
	 * @throws ConnectException
	 * @throws RemoteException
	 */
	private static ArrayList<Item> getAvailableAuctionsRequest(Auction a) throws ConnectException, RemoteException {
		return a.getAvailableAuctions();
	}


	public static ArrayList<Item> getAvailableAuctions(Auction a) throws Exception {
		try {
			return getAvailableAuctionsRequest(a);
		} catch (ConnectException | RemoteException e) {
			Auction nextAvailableService = reconnect();
			a = nextAvailableService;
			return getAvailableAuctionsRequest(nextAvailableService);
		}
	}
}
