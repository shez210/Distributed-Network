package auctioneer;

import java.io.*;
import java.security.PublicKey;

/**
 * Class for the user which implements serializable
 * use serial to save the user
 */
public class User implements Serializable {
    String email;
    String userName;
    PublicKey pubKey;
    public static final long serialVersionUID = 42L;

    /**
     * The constructor for the User in which passes in their details as said in the spec
     * @param userName = the username of THAT user
     * @param email = the email attached to THAT user
     * @param pubkey = the pubkey attached to THAT user
     */
    public User(String userName, String email, PublicKey pubkey) {
        this.userName = userName;
        this.email = email;
        this.pubKey = pubkey;
    }

    /**
     * returns the username
     * @return
     */
    public String getUserName(){
        return userName;
    }

    /**
     * returns email
     * @return
     */
    protected String getEmail(){
        return email;
    }

    protected PublicKey getPubKey() {
        return pubKey;
    }
    
    public String toString() {
        return "Name: '" + this.userName + "', email: '" + this.email + "'";
    } 
}
