package auctioneer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class Item implements Serializable {
    int ID;
    double reserve;
    double currentPrice;
    boolean won;
    String name;
    String description;
    User owner;
    User bidder;
    public static final long serialVersionUID = 42L;

    private static ArrayList<Integer> usedID = new ArrayList<>();

    /**
     * Constructor for the Item.
     * @param user = the current user for the current session
     * @param name = the item name in which is bound to THAT user.
     * @param description = the description of the item
     * @param startPrice = the start price of the item when added
     * @param reserve = the reserve price (the least amount you would want)
     */
    public Item(User user, String name, String description, double startPrice, double reserve) {
        this.name = name;
        this.description = description;
        this.reserve = reserve;

        do
        {
            this.ID = new Random().nextInt(9999);
        }while(!checkID(this.ID));

        this.currentPrice = startPrice;
        this.won = false;
        this.owner = user;
        this.bidder = user;
    }

    /**
     * Checks to see if ID has been used
     * @param id
     * @return
     */
    private static boolean checkID(int id)
    {
        for(int i = 0, s = usedID.size(); i < s; i++)
        {
            if(usedID.get(i) == id)
            {
                return false;
            }
        }

        return true;
    }

    /**
     * Method to return ID
     * @return
     */
    public int getID(){
        return ID;
    }

    /**
     * Returns Reserve Price
     * @return
     */
    protected double getReserve(){
        return reserve;
    }

    /**
     * returns current Price
     * @return
     */
    public double getCurrentPrice(){
        return currentPrice;
    }

    /**
     * returns item description
     * @return
     */
    public String getDescription(){
        return description;
    }

    /**
     * Returns Item name
     * @return
     */
    public String getName(){
        return name;
    }

    protected String getOwner() {
        return this.owner.email;
    }
    protected String getBidder() {
        return this.bidder.email;
    }

    protected String getBidderName() {
        return this.bidder.email;
    }

    protected String getOwnerName() {
        return this.owner.email;
    }
    protected void setBidder(User user) {
        this.bidder = user;
    }
    protected void setPrice(double price) {
        this.currentPrice = price;
    }

    public String toString() { 
        return "ID: '" + this.ID + "', name: '" + this.name + "' , price : '" + currentPrice + "'";
    } 
}