package helper;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

/**
 * Class to encrypt and decrypt the challenge. We use DES for assymmetric
 */
public class CrytpoHelper {
    /**
     * Get the DES Key.
     * @return Generate a secret key
     */
    public static SecretKey getDESKey() {
        try {
            SecretKeyFactory sf = SecretKeyFactory.getInstance("DES");
            return sf.generateSecret(new DESKeySpec(
                    new byte[] {0x10,0x20,0x30,0x40,0x50,0x60,0x70,(byte) 0x80}));
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        throw new RuntimeException("I can't create the key :(");
    }

    /**
     * Decrypt the secret key using DES mode.
     * @return the cipher which has been decrypted.
     */
    public static Cipher decryptCipher() {
        Cipher cipher = null;
        try {
            cipher = Cipher.getInstance("DES");
            cipher.init(Cipher.DECRYPT_MODE, getDESKey());
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return cipher;
    }

    public static Cipher encryptCipher() {
        Cipher cipher = null;
        try {
            cipher = Cipher.getInstance("DES");
            cipher.init(Cipher.ENCRYPT_MODE, getDESKey());
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return cipher;
    }
}
