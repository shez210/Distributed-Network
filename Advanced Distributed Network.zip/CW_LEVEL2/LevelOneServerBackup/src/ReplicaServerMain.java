import java.util.Scanner;

import auctioneer.AuctioneerReplicaServer;

public class ReplicaServerMain {
	
	AuctioneerReplicaServer replicaServer = new AuctioneerReplicaServer();
	
	/**
	 * 
	 * @throws Exception
	 */
	protected void start() throws Exception {
		replicaServer.start();
		System.out.println("Replica Server is running ");
	}
	
	/**
	 * Stop the Server
	 * 	Stop the Cluster which stops state replication for this Node
	 * 
	 */
	protected void stop() {
		try {
			replicaServer.stop();
		} catch (Exception e) {
			System.out.println(" Error in stopping the server " + e.getLocalizedMessage());
			System.exit(1);
		}
	}
	
	public static void main(String args[]) {
		ReplicaServerMain replicateServerMain = new ReplicaServerMain();
		try {
			replicateServerMain.start();
			char input;
			Scanner inputScanner = new Scanner(System.in);
			do {
				input = inputScanner.next().charAt(0);
			} while (input != 'q');

			inputScanner.close();
		} catch (Exception e) {
			System.out.println("Cannot start Replica server " + e.getLocalizedMessage());
		} finally {
			replicateServerMain.stop();
		}
	}
}
