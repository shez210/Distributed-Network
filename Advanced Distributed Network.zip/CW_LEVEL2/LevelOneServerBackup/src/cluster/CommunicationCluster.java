package cluster;

import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jgroups.Address;
import org.jgroups.JChannel;
import org.jgroups.Membership;
import org.jgroups.MembershipListener;
import org.jgroups.StateListener;
import org.jgroups.View;
import org.jgroups.blocks.RpcDispatcher;
import org.jgroups.protocols.pbcast.GMS;
import org.jgroups.stack.MembershipChangePolicy;
import org.jgroups.stack.Protocol;
import auctioneer.AuctioneerFEServer;
import auctioneer.Item;
import auctioneer.User;

public abstract class CommunicationCluster  implements MembershipListener , MembershipChangePolicy, StateListener  {

	public static String CLUSTER_NAME = "AuctioneerCluster";

	protected JChannel channel;
	protected RpcDispatcher disp=null;
	public static Map<Short,Method> methods;//map of remote methods to be called
	public List<Address> replicas = new ArrayList<>(); //A list of all replica(s) being run
	
	boolean isFEServer = true;
	/**
	 * Users and Items data consistent storage at the Replica server
	 */
	protected Map<String , Object> state = null;//map of all states to THAT replica

	/**
	 * Start the JGroups Cluster. New node joins with already existing members in the Cluster
	 * Set FE Server logical address name as FEServer for not making FEServer as the coordinator 
	 * to transfer the state when new Replica Server joins
	 * One of the Replica Server is always coordinator
	 * After connecting the channel
	 * @throws Exception
	 */
	public void startCluster(boolean isFEServer) throws Exception {
		try {
			this.isFEServer = isFEServer;
			channel = new JChannel();
			if(isFEServer) {
				channel.setName("FEServer");
			}

			/****What is this?***/
			List<Protocol> protocols = channel.getProtocolStack().getProtocols();//gets all protocols in the JChannel TCP -> GMS ->
	        for (Protocol p : protocols) {
	        	if(p.getName().equals("GMS")) {//if protocol is GMS
	        		GMS gms = (GMS) p; 
	        		//gms.level("Error");
	        		gms.setMembershipChangePolicy((MembershipChangePolicy) this);
	        		break;
	        	}
	        }        
			disp=new RpcDispatcher(channel, this).setMethodLookup(id -> AuctioneerFEServer.methods.get(id));//RPC dispatcher looks up method via ID
			state = Collections.synchronizedMap(new HashMap<String, Object>());//putting states in a synchronized map. For concurrent read and writes
			disp.setMembershipListener(this).setStateListener(this);//gives control to getstate and set state
			channel.connect(CLUSTER_NAME, null, 0);
			System.out.println("Connected to cluster :" + CLUSTER_NAME);
		} catch (Exception e) {
			throw new Exception("Failed to connect to cluster : " + CLUSTER_NAME  + " " + e.getLocalizedMessage());
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.jgroups.stack.MembershipChangePolicy#getNewMembership(java.util.Collection, java.util.Collection, java.util.Collection, java.util.Collection)
	 * Control the Cluster Membership view so that Replica is always coordinator
	 */
	@Override
	public List<Address> getNewMembership(Collection<Address> current,
            								Collection<Address> joiners,
            								Collection<Address> leavers,
            								Collection<Address> suspects) {
		Membership retval=new Membership(); // prevents duplicates
		Address feserver = null;
		for(Address addr: current) {//for all replicas
			if(addr.toString().equalsIgnoreCase("FEServer"))//doesnt make FE a coordinator
				feserver = addr;//skip and store the ddress of FE server
			else
				retval.add(addr);//it is replica add it to the return list
		}
		
		for(Address addr: joiners) {
			if(addr.toString().equals("FESerer")) //skip FE Server
				feserver = addr;
			else
				retval.add(addr);
		}
		retval.remove(leavers).remove(suspects); // remove disconnected node
		
		if(feserver != null)  //add FE Server to the end of membership (it is not corodinator of state)
			retval.add(feserver);
		return retval.getMembers();
	}
	
	/**
	 * Stop ReplicatedHashMap and Cluster
	 */
	public void stopCluster() {
		if(channel != null) {
			disp.stop();
			channel.close();
		}
	}

	/*
	 * Return number of Replicas avaialble from the cluster view
	 * Requests are forwared to these replicas
	 */
	protected List<Address> getAvailableReplicas() throws Exception {
		synchronized(replicas){
			int numberofReplicas = replicas.size();//goes through replica list and sees how many is connected to cluster
			if(numberofReplicas >= 1) {//if more than 1 replica running
				return replicas;
			}
			else
				throw new Exception("Replica Server(s) are not available to process the request");
		}
	}

	/*
	 * (non-Javadoc)
	 * @see org.jgroups.MembershipListener#viewAccepted(org.jgroups.View)
	 * When a new node joins or leaves update the available Replicas list
	 * After we our required membership, call this function to view information.
	 */
	public void viewAccepted(View new_view) {
		List<Address> new_mbrs=new_view.getMembers();
		if(new_mbrs != null) {
			synchronized(replicas){
				replicas.clear();
				for(Address member : new_mbrs) {
					if(!member.toString().equals("FEServer")) {
						replicas.add(member);
					}
				}
			}
		}
		System.out.println(new_view);
	}

	/*
	 * print consistent data state of the Replicas
	 */
	private void printState() {
		List<User> users = (List<User>) state.get("users");
		if(users == null)
			users =  new ArrayList<User>();

		List<Item> items =  (List<Item>) state.get("items");
		if(items == null)
			items = new ArrayList<Item>();

		if(users != null)
			System.out.println("Users State " + Arrays.toString(users.toArray()));
		else
			System.out.println("Users State []");
		if(items != null)
			System.out.println("Items State " + Arrays.toString(items.toArray()));
		else
			System.out.println("Items State []");
	}
	
	 /*----------------------------------------------------------*/

    /*-------------------- State Exchange ----------------------*/
    public void getState(OutputStream ostream) throws Exception {
        HashMap<String,Object> copy=new HashMap<>();//Creating a new hashmap to be sent over to the new replica
        for(Map.Entry<String,Object> entry : state.entrySet()) {//for each sate
        	String key=entry.getKey();//map the key to entry key
        	Object val=entry.getValue();//map the value to the values
            copy.put(key, val);//put these recorsd in the tree and send over
        }
        try(ObjectOutputStream oos=new ObjectOutputStream(new BufferedOutputStream(ostream, 1024))) {
            oos.writeObject(copy);//put the hashmap into an object output stream to be sent
        }
        System.out.println("Sending State to new Replica");
    }

	/**
	 * This is what is called on receiving side (new replica)
	 * @param istream
	 * @throws Exception
	 */
	public void setState(InputStream istream) throws Exception {
        HashMap<String,Object> new_copy=null;//a hashmap to read the requested copy
        try(ObjectInputStream ois=new ObjectInputStream(istream)) {
            new_copy=(HashMap<String,Object>)ois.readObject();//read in the new hash updated hash map
        }
        if(new_copy != null)
            state.putAll(new_copy);
        System.out.println("Received State from Cluster");
        printState();//printing the received state
    }
}
