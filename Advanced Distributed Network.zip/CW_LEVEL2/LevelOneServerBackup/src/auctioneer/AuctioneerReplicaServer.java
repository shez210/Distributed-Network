package auctioneer;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import cluster.CommunicationCluster;
import org.jgroups.Address;

public class AuctioneerReplicaServer extends CommunicationCluster  {

	public AuctioneerReplicaServer() {
	}
	
	/**
	 * Start the Replica Server by setting isFEServer to false
	 * @throws Exception
	 */
	public void start() throws Exception {
		boolean isFEServer = false;
		super.startCluster(isFEServer);
	}

	/**
	 * Stop the Replica Cluster 
	 */
	public void stop() {
		super.stopCluster();
	}

	/**
	 * Fetch the Items from consistent data which is in sync with other Replicas
	 * @return List of Users
	 */
	@SuppressWarnings("unchecked")
	public List<Item> getItemsFromReplica() {//gets the items from local replica and returns this
		List<Item> items =  (List<Item>) state.get("items");
		if(items == null)
			return new ArrayList<Item>();
		return (List<Item>) state.get("items");
	}

	/**
	 * Fetch the Users from consistent data which is in sync with other Replicas
	 * @return List of Users
	 */
	@SuppressWarnings("unchecked")
	public List<User> getUsersFromReplica() {//gets the users from local replica and returns users
		List<User> users = (List<User>) state.get("users");
		if(users == null)
			return new ArrayList<User>();
		return (List<User>) state.get("users");
	}
	
	/**
	 * Bid method which will need to be invocated remotely between server and client
	 *
	 * @param ID        = The id of THAT item that the buyer is bidding for
	 * @param bidAmount = The amount in which is being bidded on
	 * @return User bidder = the bidder on THAT item
	 * @throws RemoteException = exception to handle remote exception such as NO CONNECTION
	 */
	public synchronized boolean bid(Integer ID, Double bidAmount, User bidder) {
		int i;
		List<Item> items = getItemsFromReplica();
		for (i = 0; i < items.size(); i++) {//goes through array list of items
			if(bidder.getUserName().equals((items.get(i).getOwnerName()))) {
				System.out.println("[-][item]: failed bid on " + items.get(i).getName() +
						" (" + items.get(i).getID() + ")");
				return false;
			}
			if (items.get(i).getCurrentPrice() < bidAmount && items.get(i).ID == ID) {
				items.get(i).currentPrice = bidAmount;
				items.get(i).bidder = bidder;
				System.out.println("[+][item]: " + items.get(i).getName()
						+ " (" + items.get(i).getID() + ") was bid on");
				//update the state to replicate to other nodes
				state.put("items", items);
				return true;
			}
		}
		System.out.println("[-][item]: failed bid on " + items.get(i).getName() +
				" (" + items.get(i).getID() + ")");
		return false;
	}

	/**
	 * Method in which adds the item to the auction
	 *
	 * @return true = item has been added
	 * false = item has not been added
	 * @throws RemoteException = exception to handle remote exception such as NO CONNECTION
	 */
	public boolean addItem(Item item) {
		List<Item> items = getItemsFromReplica();
		if (items.add(item)) {
			System.out.println("[+][item]: " + item.getName() +
					" (" + item.getID() + ")" + " " + item.getDescription() + " " + "added to the auction list");
			//update the state to replicate to other nodes
			state.put("items", items);
			return true;
		}
		return false;
	}

	/**
	 * Method to Add a user to the ArrayList
	 *
	 * @return true if added, false if not
	 * @throws RemoteException
	 */
	public boolean addUser(User user) {
		int i;
		List<User> users = getUsersFromReplica();
		for (i = 0; i < users.size(); i++) {
			if (users.get(i).getEmail().equalsIgnoreCase(user.getEmail())) {//if email is in arraylit, dont add it
				System.out.println("[-][user]: attempted to add duplicate user " + user.getEmail());
				return false;
			}
		}
		users.add(user);
		System.out.println("[+][user]: " + user.getEmail() + " was registered");
		//update the state to replicate to other nodes
		state.put("users", users);
		return true;
	}


	/**
	 * ArrayList for all Auctions
	 *
	 * @return - All elements of arraylist (Auctions)
	 */
	public ArrayList getAvailableAuctions() {
		ArrayList<Item> auctions = new ArrayList<Item>();
		int i;
		List<Item> items = getItemsFromReplica();
		for (i = 0; i < items.size(); i++) {
			if (items.get(i).won == false) {//items that havent been won, add it
				auctions.add(items.get(i));
			}
		}

		return auctions;
	}

	/**
	 * Method to return won auctions
	 *
	 * @return the arraylist of auctions that have been won
	 */
	public ArrayList getWonAuctions(User user) {
		ArrayList<Item> auctions = new ArrayList<Item>();
		String email = user.getEmail();

		int i;
		List<Item> items = getItemsFromReplica();
		for (i = 0; i < items.size(); i++) {
			if (items.get(i).won == true) {
				if (items.get(i).bidder.getEmail().equalsIgnoreCase(email)) {
					auctions.add(items.get(i));//the items that bidder has won
					//add it to the list
				}
			}
		}
		return auctions;
	}

	/**
	 * Method to close an Auction
	 *
	 * @param id   = the item id of that item in which is being closed
	 * @param user = the user that is closing it (usually the owner)
	 * @return
	 */
	public String closeAuction(Integer id, User user) {
		int i;
		String message = "";
		List<Item> items = getItemsFromReplica();
		for (i = 0; i < items.size(); i++) {
			if (items.get(i).getID() == id && items.get(i).owner.getUserName().equalsIgnoreCase(user.getUserName())) {
				items.get(i).won = true;
				if (items.get(i).getCurrentPrice() > items.get(i).getReserve()) {
					System.out.println("[+][item]: " + items.get(i).getName() +
							" (" + items.get(i).getID() + ") was closed and beat its reserve");
					message = "2 " + items.get(i).bidder.getEmail();//returns the email of winner
				} else {
					System.out.println("[+][item]: " + items.get(i).getName() + " (" + items.get(i).getID() + ") was closed but didn't beat reserve");
					message = "1";
				}
				//update the state to replicate to other nodes
				state.put("items", items);
				return message;
			}
		}
		System.out.println("[-][item]: " + items.get(i).getName() + " (" + items.get(i).getID() + ") could not be closed");
		return "0";
	}

	@Override
	public List<Address> getNewMembership(Collection<Collection<Address>> collection) {
		return null;
	}
}