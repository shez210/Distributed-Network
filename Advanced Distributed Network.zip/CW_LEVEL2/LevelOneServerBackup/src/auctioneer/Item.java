package auctioneer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class Item implements Serializable {
    
	int ID;
    double reserve;
    double currentPrice;
    boolean won;
    String name;
    String description;
    User owner;
    User bidder;
    
    public static final long serialVersionUID = 42L;

    private static ArrayList<Integer> usedID = new ArrayList<>();

    /**
     * Constructor for the Item.
     * @param user = the current user for the current session
     * @param name = the item name in which is bound to THAT user.
     * @param description = the description of the item
     * @param startPrice = the start price of the item when added
     * @param reserve = the reserve price (the least amount you would want)
     */
    public Item(User user, String name, String description, double startPrice, double reserve) {
        this.name = name;
        this.description = description;
        this.reserve = reserve;

        do
        {
            this.ID = new Random().nextInt(9999);
        }while(!checkID(this.ID));

        this.currentPrice = startPrice;
        this.won = false;
        this.owner = user;
        this.bidder = user;
    }

    /**
     * Checks to see if ID has been used
     * @param id
     * @return
     */
    private static boolean checkID(int id)
    {
        for(int i = 0, s = usedID.size(); i < s; i++)
        {
            if(usedID.get(i) == id)
            {
                return false;
            }
        }

        return true;
    }

    /**
     * Method to return ID
     * @return
     */
    public int getID(){
        return ID;
    }

    /**
     * Returns Reserve Price
     * @return
     */
    protected double getReserve(){
        return reserve;
    }

    /**
     * returns current Price
     * @return
     */
    public double getCurrentPrice(){
        return currentPrice;
    }

    /**
     * returns item description
     * @return
     */
    public String getDescription(){
        return description;
    }

    /**
     * Returns Item name
     * @return
     */
    public String getName(){
        return name;
    }

    protected String getBidderName() {
        return this.bidder.email;
    }

    protected String getOwnerName() {
        return this.owner.email;
    }
    protected void setBidder(User user) {
        this.bidder = user;
    }
    protected void setPrice(double price) {
        this.currentPrice = price;
    }
    
    public boolean isWon() {
		return won;
	}

	public void setWon(boolean won) {
		this.won = won;
	}

	public static ArrayList<Integer> getUsedID() {
		return usedID;
	}

	public static void setUsedID(ArrayList<Integer> usedID) {
		Item.usedID = usedID;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public void setReserve(double reserve) {
		this.reserve = reserve;
	}

	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}
	    
	@Override
    public boolean equals(Object other) {
        // self check
        if (this == other)
            return true;
        // null check
        if (other == null)
            return false;
        // type check and cast
        if (getClass() != other.getClass())
            return false;
        Item otherItem = (Item) other;
        
        if(otherItem.getID() != this.ID) return false;
        if(!otherItem.getName().equals(this.name)) return false;
        if(!otherItem.owner.equals(this.owner)) return false;
        if(!otherItem.getDescription().equals(this.description)) return false;
        if(otherItem.getReserve() != this.reserve) return false;
        if(otherItem.getCurrentPrice() != this.currentPrice) return false;
        if(otherItem.isWon() != this.won) return false;
        if(!otherItem.bidder.equals(this.bidder)) return false;
        if(!otherItem.getUsedID().equals(this.usedID)) return false;
        return true;
    }
    

    public String toString() { 
        return "ID: '" + this.ID + "', name: '" + this.name + "' , price : '" + currentPrice + "'";
    } 
}