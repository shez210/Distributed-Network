package auctioneer;

import javax.crypto.SealedObject;
import java.io.Serializable;
import java.rmi.*;
import java.util.ArrayList;

public interface Auction extends Remote {

    public static int FE_SERVICE_PORT = 2020;//port which server runs on

    public static String FE_SERVICE_NAME = "AuctioneerService";//service name

    /**
     * Bid method which will need to be invocated remotely between server and client
     * @param itemID = The id of THAT item that the buyer is bidding for
     * @param bidAmount = The amount in which is being bidded on
     * @return int bid = the bid on THAT item ID
     * @throws RemoteException = exception to handle remote exception such as NO CONNECTION
     */
    public boolean bid(Integer itemID, Double bidAmount, User bidder)
            throws RemoteException;

    /**
     * Method in which adds the item to the auction
     * @param item = adding the item through the ITEM class (name, description, prices etc)
     * @return true = item has been added
     *         false = item has not been added
     * @throws RemoteException  = exception to handle remote exception such as NO CONNECTION
     */
    public boolean addItem(Item item)
            throws RemoteException;

    /**
     * Method in which closes the auction by the Owner/User
     * @param id = the item id of that item in which is being closed
     * @param user = the user that is closing it (usually the owner)
     * @return int = returns the int in which mapped according to the result shown in Client.
     * @throws RemoteException
     */
    public String closeAuction(Integer id, User user)
            throws RemoteException;

    /**
     *
     * @param user
     * @return
     * @throws RemoteException
     */
    public boolean addUser(User user)
            throws RemoteException;

    /**
     *
     * @param user
     * @return
     * @throws RemoteException
     */
    public boolean login(User user)
            throws RemoteException;

    /**
     *
     * @return
     * @throws RemoteException
     */
    public ArrayList getAvailableAuctions()
            throws RemoteException;

    /**
     *
     * @param user
     * @return
     * @throws RemoteException
     */
    public ArrayList getWonAuctions(User user)
            throws RemoteException;

    /**
     * Method for the signing of the sealed object
     * @param object the object being sent over network
     * @return the sealed object which has been signed
     * @throws RemoteException
     */
    SealedObject sign(SealedObject object)
            throws RemoteException;

    /**
     * The challenge between server and client and vice versa
     * @param userName attaches the username to see who has sent it
     * @return the challenge in the sealed object
     * @throws RemoteException
     */
    SealedObject challenge(String userName)
            throws RemoteException;

    /**
     * The answer to THAT challenge
     * @param userName the username from the challenge
     * @param sealedObject The sealed object it has come in
     * @throws RemoteException
     */
    void challengeAnswer(String userName, SealedObject sealedObject)
            throws RemoteException;
}
