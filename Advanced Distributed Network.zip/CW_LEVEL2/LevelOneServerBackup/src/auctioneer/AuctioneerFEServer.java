package auctioneer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignedObject;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.DSAPublicKey;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import javax.crypto.SealedObject;

import org.jgroups.Address;
import org.jgroups.blocks.MethodCall;
import org.jgroups.blocks.RequestOptions;
import org.jgroups.blocks.ResponseMode;
import org.jgroups.blocks.RspFilter;
import org.jgroups.util.Rsp;
import org.jgroups.util.RspList;

import cluster.CommunicationCluster;
import helper.CrytpoHelper;

public class AuctioneerFEServer extends CommunicationCluster implements Auction  {

	public static Map<Short,Method> methods;//putting each RPC into a map
	private long call_timeout=10000L;  //Remote method execution timeout

	// directory with pubs & private keys
	// server must have server priv key, clients shouldn't
	private static final String AUCTION_HOME = System.getProperty("user.home")+"/auction";
	public static KeyPair kp = null;
	private Signature signature = null;

	private static final short BID=1;
	private static final short ADDITEM=2;
	private static final short CLOSEAUCTION=3;
	private static final short ADDUSER=4;
	private static final short GETAVAILABLEAUCTIONS=5;
	private static final short GETWONAUCTIONS=6;
	private static final short GETUSERS=7;
	private static final short GETITEMS=8;

	private Map<Integer, ReentrantLock> bidEntryLocks = new ConcurrentHashMap<>();//Map for bidding using a Re-Entrant lock

	/**
	 * Remote Methods list passed to Replica Servers
	 */
	static {
		try {
			methods=new HashMap<>();

			methods.put(BID, AuctioneerReplicaServer.class.getMethod("bid",
					Integer.class,
					Double.class,
					User.class));//put the method "bid" into the hashMap. Send bid to client

			methods.put(ADDITEM, AuctioneerReplicaServer.class.getMethod("addItem",
					Item.class
					));

			methods.put(CLOSEAUCTION, AuctioneerReplicaServer.class.getMethod("closeAuction",
					Integer.class,
					User.class
					));

			methods.put(ADDUSER, AuctioneerReplicaServer.class.getMethod("addUser",
					User.class
					));

			methods.put(GETAVAILABLEAUCTIONS, AuctioneerReplicaServer.class.getMethod("getAvailableAuctions"
					));

			methods.put(GETWONAUCTIONS, AuctioneerReplicaServer.class.getMethod("getWonAuctions",
					User.class
					));

			methods.put(GETUSERS, AuctioneerReplicaServer.class.getMethod("getUsersFromReplica"
					));

			methods.put(GETITEMS, AuctioneerReplicaServer.class.getMethod("getItemsFromReplica"
					));
		}
		catch(NoSuchMethodException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Start the FE Server by setting isFEServer to true
	 * Generate a Digital signature
	 * @throws Exception
	 */
	public void start() throws Exception {
		this.signature = Signature.getInstance("DSA");
		kp = generateKeys();
		boolean isFEServer = true;
		super.startCluster(isFEServer);	
	}

	/**
	 * Stop the FE Server by setting isFEServer to true
	 * @throws Exception
	 */
	public void stop() {
		super.stopCluster();
	}

	/**
	 * This is the challenge sent to the USER. Send challenge encrypted
	 * @param userName attaches the username to see who has sent it
	 * @return the sealed object sent to user (challenge)
	 * @throws RemoteException
	 */
	@Override
	public SealedObject challenge(String userName) throws RemoteException {
		List<User> users = null;
		try {
			users = getUsers();
			for (int i = 0; i < users.size(); i++) {
				if (users.get(i).getUserName().equalsIgnoreCase(userName)) {//find username
					try {
						System.out.println("[+][user]: " + userName + " found, sending challenge");
						return new SealedObject(new Random().nextInt(), CrytpoHelper.encryptCipher());
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}

		} catch (Exception e) {
			throw new RuntimeException(userName + " User not found :( " + e.getLocalizedMessage());
		}
		return null;
	}

	/**
	 * Sending and receiving and decrypting challenge from user
	 * Verifying the signaure using the public key of user
	 * @param userName the username from the challenge
	 * @param sealedObject The sealed object it has come in
	 * @throws RemoteException
	 */
	@Override
	public void challengeAnswer(String userName, SealedObject sealedObject) throws RemoteException {
		try {
			List<User> users = getUsers();
			for (int i = 0; i < users.size(); i++) {
				if (users.get(i).getUserName().equalsIgnoreCase(userName)) {//find username
					try {
						System.out.println("[+][user]: " + userName + " found, Receiving and decrypting challenge");
						SignedObject signedObject = (SignedObject) sealedObject.getObject(CrytpoHelper.decryptCipher());
						System.out.println("[+][user]: " + userName + " Received challenge...verifying signature");
						if (!signedObject.verify(users.get(i).pubKey, this.signature)) {
							throw new RemoteException("Unverified.");
						}
						System.out.println("[AUTH] " + userName + " signature has been verified!");
						System.out.println("[AUTH] " + userName + " has been verified!");
					} catch (Exception ex ) {

					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("[AUTH] User #" + userName + " has failed!");
			throw new RuntimeException("Failed to authenticate");
		}
	}

	/**
	 * This is a method for signing the object with private key. Creating signature
	 * @param theObject
	 * @return
	 * @throws RemoteException
	 */
	@Override
	public SealedObject sign(SealedObject theObject) throws RemoteException {
		SealedObject obj = null;

		try {
			SignedObject signedObj = new SignedObject((Serializable )theObject.getObject(CrytpoHelper.decryptCipher()), kp.getPrivate(), this.signature);//creating signature via private key

			return new SealedObject(signedObj, CrytpoHelper.encryptCipher());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

	/**
	 * SANITY CHECK..checks to see if response received from replica server is good
	 * @param rsp
	 * @return
	 */
	private boolean isValidResponse(Rsp rsp) {
		if(rsp.wasReceived() && !rsp.wasSuspected()) {//if response sent and not disconnected
			Object obj=rsp.getValue();//return value of the function executed on replica(boolean, string, list)
			if(obj != null && !(obj instanceof Throwable))//if object isnt null and has exceptions
				return true;
		}
		return false;
	}

	/*
	 * Get Users data from the Replica servers
	 * RPC the available replica and get all responses from all replicas
	 */
	public List<User> getUsers() throws Exception {
		List<User> finalusers = null;
		try {
			RspList<Object> rsps=disp.callRemoteMethods(getAvailableReplicas(),//RSP list - contains response from all replicas. Response from all available replicas
					new MethodCall(GETUSERS),//Calling a new remote method using the ID. Replica side - correspondin method is picked up and executed via methodsMap
					new RequestOptions(ResponseMode.GET_ALL, call_timeout));//request all replies from all replicas. Any replicas that reach timeout, then drop the response.
			for(Rsp rsp: rsps.values()) {//loop through results
				if(!isValidResponse(rsp)) {//check if valid
					throw new Exception("Unable to get Users Data from Replica " + rsp.getException());
				}
				if(finalusers == null)//the sanity response check (first response)
					finalusers = (List<User>)rsp.getValue();//first response
				else {
					List<User> currentResponse = (List<User>)rsp.getValue();//2nd response
					if(finalusers.equals(currentResponse))//first  = second
						continue;
					else
						throw new Exception("Replicas Users data is out of sync ");
				}
			}
			return finalusers;
		}
		catch(Throwable t) {
			throw new Exception("Unable to get Users Data from Replicas " + t.getLocalizedMessage());
		}
	}

	/*
	 * Get Items data from the Replicas
	 */
	protected List<Item> getItems() throws Exception {
		List<Item> finalitems = null;
		try {
			RspList<Object> rsps=disp.callRemoteMethods(getAvailableReplicas(),//RSP list - contains response from all replicas. Response from all available replicas
					new MethodCall(GETITEMS),//Calling a new remote method using the ID. Replica side - correspondin method is picked up and executed via methodsMap
					new RequestOptions(ResponseMode.GET_ALL, call_timeout));//request all replies from all replicas. Any replicas that reach timeout, then drop the response.

			for(Rsp rsp: rsps.values()) {//loop through results
				Object obj=rsp.getValue();
				if(!isValidResponse(rsp)) {//check if valid
					throw new Exception("Unable to get Items Data from Replica " + rsp.getException());
				}
				if(finalitems == null)//the sanity response check (first response)
					finalitems = (List<Item>)rsp.getValue();//first response
				else {
					List<Item> currentResponse = (List<Item>)rsp.getValue();//2nd response
					if(finalitems.equals(currentResponse))//first  = second
						continue;
					else
						throw new Exception("Replicas Items data is out of sync ");
				}
			}
			return finalitems;
		}
		catch(Throwable t) {
			throw new Exception("Unable to get Items Data from Replicas : " + t.getLocalizedMessage());
		}
	}

	/**
	 * Bid method which will need to be invocated remotely between server and client
	 *
	 * @param itemID = The id of THAT item that the buyer is bidding for
	 * @param bidAmount = The amount in which is being bidded on
	 * @return User bidder = the bidder on THAT item
	 * @throws RemoteException = exception to handle remote exception such as NO CONNECTION
	 */
	@Override
	public synchronized boolean bid(Integer itemID, Double bidAmount, User bidder) throws RemoteException {
		Boolean finalresponse = null;
		ReentrantLock lock = bidEntryLocks.get(itemID);
		if(lock == null) {
			bidEntryLocks.putIfAbsent(itemID, new ReentrantLock());//each itemID has its own re-entrant lock. putIfAbsent - use it if itemID is free else wait
		}
		try {
			lock.lock();//lock the lock
			MethodCall call=new MethodCall(BID, itemID, bidAmount, bidder);//Calling a new remote method using the ID. Replica side - correspondin method is picked up and executed via methodsMap
			RspList<Object> rsps=disp.callRemoteMethods(getAvailableReplicas(),//RSP list - contains response from all replicas. Response from all available replicas
					call,
					new RequestOptions(ResponseMode.GET_ALL, call_timeout));//request all replies from all replicas. Any replicas that reach timeout, then drop the response.
			for(Rsp rsp: rsps.values()) {//loop through results
				if(!isValidResponse(rsp)) {//check if valid
					throw new Exception("Unable to Bid " + rsp.getException());
				}
				if(finalresponse == null)//the sanity response check (first response)
					finalresponse = (boolean)rsp.getValue();//first response
				else {
					boolean currentResponse = (boolean)rsp.getValue();//2nd response
					if(finalresponse == currentResponse)//first  = second
						continue;
					else
						throw new Exception("Replicas data is out of sync and unable to bid");
				}
			}
			return finalresponse;
		}
		catch(Throwable t) {
			throw new RemoteException("Unable to bid at Replicas : " + t.getLocalizedMessage());
		} finally {
			lock.unlock();//if bid sucessfull, then unlock
		}
	}

	/**
	 * Method in which adds the item to the auction
	 *
	 * @return true = item has been added
	 * false = item has not been added
	 * @throws RemoteException = exception to handle remote exception such as NO CONNECTION
	 */
	public boolean addItem(Item item) throws RemoteException {
		Boolean finalresponse = null;
		try {
			MethodCall call=new MethodCall(ADDITEM, item);//Calling a new remote method using the ID. Replica side - correspondin method is picked up and executed via methodsMap
			RspList<Object> rsps=disp.callRemoteMethods(getAvailableReplicas(),//RSP list - contains response from all replicas. Response from all available replicas
					call,
					new RequestOptions(ResponseMode.GET_ALL, call_timeout));//request all replies from all replicas. Any replicas that reach timeout, then drop the response.
			for(Rsp rsp: rsps.values()) {//loop through results
				if(!isValidResponse(rsp)) {//check if valid
					throw new Exception("Unable to add Item " + rsp.getException());
				}
				if(finalresponse == null)//the sanity response check (first response)
					finalresponse = (boolean)rsp.getValue();//first response
				else {
					boolean currentResponse = (boolean)rsp.getValue();//2nd response
					if(finalresponse == currentResponse)//first  = second
						continue;
					else
						throw new Exception("Replicas data is out of sync and unable to add Item");
				}
			}
			return finalresponse;
		}
		catch(Throwable t) {
			throw new RemoteException("Unable to add Item at Replicas " + t.getLocalizedMessage());
		}
	}

	/**
	 * Method to Add a user to the ArrayList
	 *
	 * @return true if added, false if not
	 * @throws RemoteException
	 */
	public boolean addUser(User user) throws RemoteException {
		Boolean finalresponse = null;
		try {
			MethodCall call=new MethodCall(ADDUSER, user);//Calling a new remote method using the ID. Replica side - correspondin method is picked up and executed via methodsMap
			RspList<Object> rsps=disp.callRemoteMethods(getAvailableReplicas(),//RSP list - contains response from all replicas. Response from all available replicas
					call,
					new RequestOptions(ResponseMode.GET_ALL, call_timeout));//request all replies from all replicas. Any replicas that reach timeout, then drop the response.
			for(Rsp rsp: rsps.values()) {//loop through results
				if(!isValidResponse(rsp)) {//check if valid
					throw new Exception("Unable to add User " + rsp.getException());
				}
				if(finalresponse == null)//the sanity response check (first response)
					finalresponse = (boolean)rsp.getValue();//first response
				else {
					boolean currentResponse = (boolean)rsp.getValue();//2nd response
					if(finalresponse == currentResponse)//first  = second
						continue;
					else
						throw new Exception("Replicas data is out of sync and unable to add User");
				}
			}
			return finalresponse;
		}
		catch(Throwable t) {
			throw new RemoteException("Unable to add add User at Replicas : " + t.getLocalizedMessage());
		}
	}

	/**
	 * ArrayList for all Auctions
	 *
	 * @return - All elements of arraylist (Auctions)
	 */
	public ArrayList getAvailableAuctions() throws RemoteException {
		ArrayList finalresponse = null;
		try {
			MethodCall call=new MethodCall(GETAVAILABLEAUCTIONS);//Calling a new remote method using the ID. Replica side - correspondin method is picked up and executed via methodsMap
			RspList<Object> rsps=disp.callRemoteMethods(getAvailableReplicas(),//RSP list - contains response from all replicas. Response from all available replicas
					call,
					new RequestOptions(ResponseMode.GET_ALL, call_timeout));//request all replies from all replicas. Any replicas that reach timeout, then drop the response.
			for(Rsp rsp: rsps.values()) {//loop through results
				if(!isValidResponse(rsp)) {//check if valid
					throw new Exception("Unable to get avaialable auctions from Replica " + rsp.getException());
				}
				if(finalresponse == null)//the sanity response check (first response)
					finalresponse = (ArrayList)rsp.getValue();//first response
				else {
					ArrayList currentResponse = (ArrayList)rsp.getValue();//2nd response
					if(finalresponse.equals(currentResponse))//first  = second
						continue;
					else
						throw new Exception("Replicas Items data is out of sync and unable to get avaialable auctions ");
				}
			}
			return finalresponse;
		}
		catch(Throwable t) {
			throw new RemoteException("Unable to get available auctions from Replicas : " + t.getLocalizedMessage());
		}
	}

	/**
	 * Method to return won auctions
	 *
	 * @return the arraylist of auctions that have been won
	 */
	public ArrayList getWonAuctions(User user) throws RemoteException {
		ArrayList finalresponse = null;
		try {
			MethodCall call=new MethodCall(GETWONAUCTIONS);//Calling a new remote method using the ID. Replica side - correspondin method is picked up and executed via methodsMap
			RspList<Object> rsps=disp.callRemoteMethods(getAvailableReplicas(),//RSP list - contains response from all replicas. Response from all available replicas
					call,
					new RequestOptions(ResponseMode.GET_ALL, call_timeout));//request all replies from all replicas. Any replicas that reach timeout, then drop the response.
			for(Rsp rsp: rsps.values()) {//loop through results
				if(!isValidResponse(rsp)) {//check if valid
					throw new Exception("Unable to get Won auctions from Replica " + rsp.getException());
				}
				if(finalresponse == null)//the sanity response check (first response)
					finalresponse = (ArrayList)rsp.getValue();//first response
				else {
					ArrayList currentResponse = (ArrayList)rsp.getValue();//2nd response
					if(finalresponse.equals(currentResponse))//first  = second
						continue;
					else
						throw new Exception("Replicas Items data is out of sync ");
				}
			}
			return finalresponse;
		}
		catch(Throwable t) {
			throw new RemoteException("Unable to get won auctions from Replicas : " + t.getLocalizedMessage());
		}
	}

	/**
	 * Method to close an Auction
	 *
	 * @param id   = the item id of that item in which is being closed
	 * @param user = the user that is closing it (usually the owner)
	 * @return
	 */
	@Override
	public String closeAuction(Integer id, User user) throws RemoteException {
		String finalresponse = null;
		try {
			MethodCall call=new MethodCall(CLOSEAUCTION, id, user);//Calling a new remote method using the ID. Replica side - correspondin method is picked up and executed via methodsMap
			RspList<Object> rsps=disp.callRemoteMethods(getAvailableReplicas(),//RSP list - contains response from all replicas. Response from all available replicas
					call, new RequestOptions(ResponseMode.GET_ALL, call_timeout));//request all replies from all replicas. Any replicas that reach timeout, then drop the response.
			for(Rsp rsp: rsps.values()) {//loop through results
				if(!isValidResponse(rsp)) {//check if valid
					throw new Exception("Unable to close auction on  Replica " + rsp.getException());
				}
				if(finalresponse == null)//the sanity response check (first response)
					finalresponse = (String)rsp.getValue();//first response
				else {
					String currentResponse = (String)rsp.getValue();//2nd response
					if(finalresponse.equals(currentResponse))//first  = second
						continue;
					else
						throw new Exception("Replicas Items data is out of sync and unable to close auction ");
				}
			}
			return finalresponse;
		}
		catch(Throwable t) {
			throw new RemoteException("Unable to close auction at Replicas : " + t.getLocalizedMessage());
		}
	}

	/**
	 * Method for a User to login
	 *
	 * @return true if logged in, false if not.
	 * @throws RemoteException
	 */
	public boolean login(User user) throws RemoteException {
		int i;
		List<User> users;
		try {
			users = getUsers();
			for (i = 0; i < users.size(); i++) {
				if (users.get(i).getUserName().equalsIgnoreCase(user.getUserName()) &&
						users.get(i).getEmail().equalsIgnoreCase(user.getEmail())) {//if username and email match, login
					System.out.println("[+][user]: " + user.getEmail() + " logged in");
					return true;
				}
			}
			System.out.println("[!][user]: " + user.getEmail() + " failed to log in");
			return false;
		} catch (Exception e) {
			throw new RemoteException("Problem in " + user + " login " + e.getLocalizedMessage());
		}
	}

	public KeyPair generateKeys() {
		try {
			File dir = new File(AUCTION_HOME);
			if (!dir.exists()) {
				dir.mkdir();

			}
			dir = new File(AUCTION_HOME+"/keys");
			if (!dir.exists()) {
				dir.mkdir();

			}
			dir = new File(AUCTION_HOME+"/keys/private");
			if (!dir.exists()) {
				dir.mkdir();

			}
			dir = new File(AUCTION_HOME+"/keys/public");
			if (!dir.exists()) {
				dir.mkdir();
			}

			// tries to find the server pub+priv keys, if they do exists, it loads them, otherwise are generated.
			String pubKeyLocation = AUCTION_HOME + "/keys/public/server.key";
			String privKeyLocation = AUCTION_HOME + "/keys/private/server.key";
			if (new File(privKeyLocation).exists() && new File(pubKeyLocation).exists()) {
				return getKeysForName("server");
			}

			KeyPairGenerator generator = KeyPairGenerator.getInstance("DSA");
			generator.initialize(1024, new SecureRandom());
			KeyPair keys = generator.generateKeyPair();


			PublicKey publicKey = keys.getPublic();
			PrivateKey privateKey = keys.getPrivate();

			ObjectOutputStream fos = new ObjectOutputStream(new FileOutputStream(pubKeyLocation));
			fos.writeObject(publicKey.getEncoded());
			fos.close();

			System.out.println("Public key written.");

			fos = new ObjectOutputStream(new FileOutputStream(privKeyLocation));
			fos.writeObject(privateKey.getEncoded());
			fos.close();

			System.out.println("Private key written.");
			return keys;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private KeyPair getKeysForName(String name) {
		String filename = name + ".key";
		String privateKeyLocation = AUCTION_HOME + "/keys/private/" + filename;
		String publicKeyLocation = AUCTION_HOME + "/keys/public/" + filename;

		// Check the file exists
		if (!new File(privateKeyLocation).exists()) {
			throw new RuntimeException("Can't find key");
		}

		if (!new File(publicKeyLocation).exists()) {
			throw new RuntimeException("Can't find key");
		}

		try {
			// Read in private key
			FileInputStream fs = new FileInputStream(new File(privateKeyLocation));
			ObjectInputStream ds = new ObjectInputStream(fs);
			byte[] prKey = (byte[]) ds.readObject();
			fs.close();
			ds.close();
			KeyFactory keyFactory = KeyFactory.getInstance("DSA");
			KeySpec ks = new PKCS8EncodedKeySpec(prKey);
			PrivateKey privateKey = (DSAPrivateKey) keyFactory.generatePrivate(ks);

			// Load in public key
			fs = new FileInputStream(new File(publicKeyLocation));
			ds = new ObjectInputStream(fs);
			byte[] puKey = (byte[]) ds.readObject();
			fs.close();
			ds.close();
			ks = new X509EncodedKeySpec(puKey);
			PublicKey publicKey = (DSAPublicKey) keyFactory.generatePublic(ks);

			return new KeyPair(publicKey, privateKey);

		} catch (Exception e) {
			throw new RuntimeException("Can't user load keys");
		}
	}

	@Override
	public List<Address> getNewMembership(Collection<Collection<Address>> collection) {
		return null;
	}
}
