import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

import auctioneer.Auction;
import auctioneer.AuctioneerFEServer;

public class FEServerMain {

	private AuctioneerFEServer a;
	
	private Registry registry;

	/**
	 * 
	 * @throws Exception
	 */

	protected void start() throws Exception {
		a = new AuctioneerFEServer();
		
		//Start the cluster first so that state will be in sync with other node
		a.start();
		
		bindRMIService();
		System.out.println("FE Server is running ");
	}

	/**
	 * Stop the Server
	 * 	Stop the Cluster which stops state replication for this Node
	 * 	unbind the stub
	 */
	protected void stop() {
		try {
			a.stop();
			registry.unbind(Auction.FE_SERVICE_NAME);
			UnicastRemoteObject.unexportObject(a, false);
		} catch (Exception e) {
			System.out.println(" Error in stopping the FE server " + e.getLocalizedMessage());
			System.exit(1);
		}
	}
	
	/**
	 * Starts the new AuctioneerService on the avaiable port from 2020 to 2020 + MAX_NUMBER_OF_SERVERS
	 * @throws Exception
	 */
	protected void bindRMIService() throws Exception  {
		Auction stub = (Auction) UnicastRemoteObject.exportObject(a, 0);
		try {
			registry = LocateRegistry.createRegistry(Auction.FE_SERVICE_PORT);
			registry.bind(Auction.FE_SERVICE_NAME, stub);
		} catch (RemoteException e) {
			registry = null;
		}
		if(registry == null)
			throw new Exception("Couldn't bind remote object, Check whether more than one FE Server is running\n\n");
	}
	
	public static void main(String args[]) {
		FEServerMain feServerMain = new FEServerMain();
		try {
			feServerMain.start();
			char input;
			Scanner inputScanner = new Scanner(System.in);
			do {
				input = inputScanner.next().charAt(0);
			} while (input != 'q');

			inputScanner.close();
		} catch (Exception e) {
			System.out.println("Cannot start FE server " + e.getLocalizedMessage());
		} finally {
			feServerMain.stop();
		}
	}
}	
